#include<stdio.h>
int main()
{
	int a;
	float b;
	printf("temperature of cities in fahrenite = ", & a);
	scanf("%d",& a);
	b=a*-17.222;
	printf("in centrigrade %f", b);
	return 0;
	 
}
