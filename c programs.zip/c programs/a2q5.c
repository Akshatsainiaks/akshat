#include <stdio.h>
int main()
{
	("INTEGERS");
	int a= 15;
	int b= 16;
	int c= 17;
	int d= 18;
	
	
	printf("first variable holds an integer constant %d \n",a);
    printf("second variable holds an integer constant %d \n",b);
    printf("third variable holds an integer constant %d \n",c);
    printf("forth variable holds an integer constant %d \n",d);
    return 0;
}
