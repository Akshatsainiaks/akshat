#include<stdio.h>
int main()
{
	
	// a=5,b=10;
int a,b;
printf("enter the value of a = ");
scanf("%d",& a);
printf("enter the value of b = ");
scanf("%d",& b);
int c=a;
a=b;
b=c;
printf("after swap a = %d and b = %d",a,b);
return 0;	
}
