#include<stdio.h>
int main()
{
int Num;
printf("enter number between 1-100 = ");
scanf("%d",& Num);	

if(Num>50)
{
	printf("SUCCESS");
	
}	

else
{
printf("FAIL");
}

return 0;
}
