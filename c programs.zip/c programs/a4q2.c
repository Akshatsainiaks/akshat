#include<stdio.h>
int main()
{
	int a=34;
	int b=25;
	printf("result is %d", a-b);
	return 0;
}
