#include<stdio.h>
int main()
{
    int i;
    float f;
    printf("Testing of various airthmetic operations\n ");
    i = 5/2.0;
    f = 5/2.0;
    printf("Value of integer i is %d \n",i);
    printf("Value of float f is %f\n", f);
    return 0;
}