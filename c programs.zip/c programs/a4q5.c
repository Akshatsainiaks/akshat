#include<stdio.h>
int main()
{
	int a;
	int b;
	int c;
	
	
	printf("enter salary = ");
	scanf("%d", &a);
	printf("ramesh salary ", &a);
    b = a+a*40/100;
printf("total salary = %d",b);
return 0;
}
