#include<stdio.h>
int main()
{
    int i;
    float f;
    printf("Testing of various airthmetic operations\n");
    i = 2.0/5;
    f = 2.0/5;
    printf("Value of integer i is %d\n",i);
    printf("value of float f is %f\n",f);
    return 0;
}