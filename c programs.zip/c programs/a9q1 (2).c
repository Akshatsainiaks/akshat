#include<stdio.h>
int main()
{
	int a,b;
	printf("enter first number = ");
	scanf("%d",& a);
	printf("enter second number = ");
	scanf("%d",& b);
	if( a>b && a>500 && a<1000)
	{
		printf("value is =  %d" ,a);
	}
	else if(b>a && b>500 && b<1000){
	
	printf("value is = %d ", b);
}
else
{
	printf("value is not greater than 500");
	
}
return 0;
}
