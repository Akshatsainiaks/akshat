#include<stdio.h>
int main()
{
    int n;
    printf("enter number of prints ");
    scanf(%d,&n);
    
}