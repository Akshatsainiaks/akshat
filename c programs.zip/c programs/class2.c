#include<stdio.h>
int main()
{
    int n;
    printf("enter weak number = ");
    scanf("%d",& n);
    switch(n)
    {
        case 1: {
            printf("monday");

        }
        case 2: {
            printf("tuesday");
        }
        case 3:{
            printf("wednesday");
        }
        case 4:{
            printf("thursday");
        }
        case 5:{
            printf("friday");
        }
        case 6:{
            printf("saturday");
break;
        }
        case 7:{
            printf("sunday");
        }
    }
    return 0;
}