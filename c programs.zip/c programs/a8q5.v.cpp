#include<stdio.h>
int main()
{
int N;
printf("enter your number = ");
scanf("%d",&N);
if(N>0)
{
printf("number is positive",N);	
}	
else if(N<0)
{
printf("number is negetive");
}
else
{
printf("number is zero");	
}
return 0;
}
