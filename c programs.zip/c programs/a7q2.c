#include<stdio.h>
int main()
{
	int N;
	printf( "  enter 1 for sum .  enter 2 for sub  .  enter 3 for multiply .  enter 4 for division .");
	scanf("%d",&N);
	 if(N==1)
	 {
	 	int a,b;
	 	printf("enter 1st number =  ");
	 	scanf("%d", & a);
	 	printf("enter 2nd number = ");
	 	scanf("%d", & b);
	 	printf("sum of both numbers is = %d", a+b);
	 }
else if (N==2)
	{
		int a;
	 	int b;
	 	printf("enter 1st number = ");
	 	scanf("%d", & a);
	 	printf("enter 2nd number = ");
	 	scanf("%d", & b);
	 	printf("difference of both numbers is = %d", a-b);
	 }
	 else if (N==3)
	 {
	 	int a;
	 	int b;
	 	printf("enter 1st number = ",& a);
	 	scanf("%d", & a);
	 	printf("enter 2nd number = ", & b);
	 	scanf("%d", & b);
	 	printf("product of both numbers is = %d", a*b);
	 }
	 else if (N==4)
	 {
	 	int a;
	 	int b;
	 	printf("enter 1st number = ",& a);
	 	scanf("%d", & a);
	 	printf("enter 2nd number = ", & b);
	 	scanf("%d", & b);
	 	printf("division of both numbers is = %d", a/b);
	 }
else
{
printf("NO OPERATION");
}


return 0;
}
