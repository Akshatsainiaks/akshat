#include<stdio.h>
int main()
{
    printf("heloo");
    return 0;
}