#include<stdio.h>
int main()
{
int a;
printf("enter number = ");
scanf("%d", & a);

if(a>0)
{
	printf("number is positive ");
	
}

else
{
	printf("number is negetive");
	
}
return 0;
}
