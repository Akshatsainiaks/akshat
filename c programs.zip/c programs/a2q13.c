#include<stdio.h>
int main()
{
	int 0=2;
	printf("%d",0);
	return 0;
}
