#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("distance between two cities in km = ", & a);
	scanf("%d", & a);
	b=a*100000;
	printf("in centimeters %d ", b);
	return 0;
}
