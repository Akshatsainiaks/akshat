#include<stdio.h>
int main()
{
	printf("TECHNO NJR INDIA");
	return 0;
}
