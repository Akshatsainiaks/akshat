#include<stdio.h>
int main()
{
	printf("AKSHAT");
	return 0;
}
