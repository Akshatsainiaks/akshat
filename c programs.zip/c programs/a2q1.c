#include<stdio.h>
int main()
{
	int a=67;
	printf("%d",a);
	return 0;
}
