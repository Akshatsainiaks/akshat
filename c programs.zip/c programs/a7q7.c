#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("enter number = ");
	scanf("%d", & a);
    b=a%5;
    if(b==0)
    {
    	printf("number is divisible by 5");
    	
	}
else
{
	printf("number is not divisible by 5");
}
return 0;
}
