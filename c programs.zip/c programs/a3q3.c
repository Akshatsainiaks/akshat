#include<stdio.h>
int main()
{
	int a;
	int b;
	int c;
	
	printf("enter value of first variable = " );
	scanf("%d", & a);
	 
	printf("enter value of second variable = " );
	scanf("%d", & b);
	
	printf("enter value of third variable = ");
	scanf("%d", & c);
	
	printf("value of first variable is %d\n", a);
	printf("value of second variable is %d\n", b);
	printf("value of third variable is %d\n", c);
	
}
