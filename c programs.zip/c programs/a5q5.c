#include<stdio.h>
int main()
{
	int l;
	int p;
	printf("write side of square = " ,& l);
	scanf("%d", & l);
	
	p=4*l;
	printf("perimeter of square = %d", p);
	return 0;
}
