#include<stdio.h>
int main()
{
	int a=5;
	int b=6;
	printf("result is %d",a*b);
	return 0;
}
