#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("heights of students in feets = ", & a);
	scanf("%d", & a);
	b=a*12;
	printf("in inches %d", b);
	return 0;
}
