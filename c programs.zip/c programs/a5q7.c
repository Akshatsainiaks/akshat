#include<stdio.h>
int main()
{
	int r;
	float c;
	printf("write radius of circle is = ", & r);
	scanf("%d",&r);
    c=2*3.14*r;
    printf("circumference of circle is = %f", c);
    return 0;
}
