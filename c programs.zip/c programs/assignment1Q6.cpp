#include<stdio.h>
int main()
{
	printf("kumar");
	return 0;
}
