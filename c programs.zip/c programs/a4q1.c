#include<stdio.h>
int main()
{
	int a=56;
	int b=89;
	printf("result is %d", a+b);
	return 0;
}
