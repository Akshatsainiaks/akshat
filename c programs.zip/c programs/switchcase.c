#include<stdio.h>
int main()
{
	int day;
	printf("enter number between 1-7 = ");
    scanf("%d",&day); 
    

	switch(day){
	//press 1 for monday
	
case 1:
        printf("monday");
		break;

case 2:
//press 2 for tuesday
    printf("tuesday");
break;

case 3:
    printf("wednesday");
break;

case 4:
printf("thursday");
break;

case 5:
	printf("friday");
break;

case 6:
	printf("saturday");

break;

case 7:
printf("sunday");
break;

default:
	printf("enter value between 1-7");
	break;

}
return 0;
}
