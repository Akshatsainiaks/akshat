#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("aman basic salary is = ",& a);
	scanf("%d", & a);
	b=a+a*50/100+a*20/100;
	printf("total (gross) salary is = %d", b);
	
}
