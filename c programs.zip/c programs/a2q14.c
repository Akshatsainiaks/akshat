#include<stdio.h>
int main()
{
	int _first=34;
	printf("%d",_first);
	return 0;
}
