#include<stdio.h>
int main()
{
int N;
printf("enter number = ");
scanf("%d",&N);
int D1=N%2;
int D2=N%3;
if(D1==0 && D2==0)
{
printf("number is divisible by 2 and 3",N);
}
else
{
printf("number is not divisible by 2 and 3",N);
}
return 0;
}
