#include<stdio.h>
#define pi 3;
int main()
    
{
	Rectangle (); 
	 void Rectangle(); 
	{
		float l,b,Rperi,Rarea;
		printf("enter length = ",& l);
		scanf("%f",& l);
		printf("enter breadth = ",& b);
		scanf("%f",& b);
		Rperi=2*(l+b);
		Rarea=l*b;
		printf(" perimeter of rectangle = %f  \n",Rperi);
		printf("area of rectangle = %f ",Rarea);
	}
	return 0;
}
