#include <stdio.h>
int main ()
{
	int a;
	int b;
	
	printf("enter value of first variable");
	scanf("%d",& a);
	
	
	printf("enter value of second variable");
	scanf("%d",& b);
	
	printf("value of first variable is  %d \n",a);
	printf("value of second variable is %d",b);
	return 0; 
}

