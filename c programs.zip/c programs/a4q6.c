#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("distance between two cites in km = ", & a);
	scanf("%d", & a);
    b=a*1000;
    printf(" in meters %d",b);
    return 0;

}
