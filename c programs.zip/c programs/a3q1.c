#include<stdio.h>
int main()
{
	int a;
	printf("enter value");
	scanf("%d",& a);
	printf("value enter by user %d",a);
    
    scanf("%d",& a);
    printf("value of variable is %d",a);
    
	 return 0;
	
}
