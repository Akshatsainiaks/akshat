#include<stdio.h>
int main()
{
int INR,USD;	
printf("enter money in US DOLLAR = ");
scanf("%d",&USD);
INR=USD*80;
printf("USD in INR is %d",INR);
return 0;

}
