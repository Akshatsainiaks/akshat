#include<stdio.h>
int main()
{
	printf("AKSHAT SAINI");
	return 0;
}
