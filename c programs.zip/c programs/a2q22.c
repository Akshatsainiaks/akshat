#include<stdio.h>
int main()
{
int 0a=67;
printf("%d",0a);
return 0;
}
