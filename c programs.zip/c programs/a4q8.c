#include<stdio.h>
int main()
{
	int a;
	int b;
	
	printf("distance between two cities in km = ", & a);
	scanf("%d", & a);
	b=a*1000000;
	printf("in millimeters %d", b);
	return 0;
}
