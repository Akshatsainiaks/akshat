#include<stdio.h>
int main()
{
    int i;
    float f;
    printf("Testing of various airthmetic operations\n");
    i = 2/5.0;
    f = 2/5.0;
    printf("Value of integer i is %d\n",i);
    printf("value of float f is %f\n",f);
    return 0;
}