#include<stdio.h>
int main()
{
int a,b;
printf("enter first number = ");
scanf("%d",&a);
printf("enter second number = ");
scanf("%d",&b);
if(a>500 && a<1000 || b>500 && b<1000)
{
printf("%d %d",a,b);
}

}
