#include<stdio.h>
int main()
{
	printf("SAINI");
	return 0;
}
