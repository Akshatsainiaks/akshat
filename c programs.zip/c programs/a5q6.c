#include<stdio.h>
int main()
{
   int 	r;
   float  a;
   printf("write radius of circle = ", & r);
   scanf("%d", & r);
   a=2*3.14*r;
   printf("area of circle is = %f ", a);
   return 0;
   
}
