#include<stdio.h>
int main()
{
	int a=5;
	int b=6;
	int c=7;
	
	("AKSHAT SAINI");
	printf("value of first variable is %d ",a);
	printf("value of second varible is %d ",b);
	printf("value of thir variable is %d",c);
	return 0;
}

