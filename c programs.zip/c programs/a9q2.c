#include<stdio.h>
int main()
{
	int M,H,E,C,P;
	printf("enter marks of maths = ");
	scanf("%d", & M);
	printf("enter marks of hindi = ");
	scanf("%d",& H);
	printf("enter marks of english = ");
	scanf("%d",& E);
	printf("enter marks of chemistry = ");
	scanf("%d",& C);
	printf("enter marks of physics = ");
	scanf("%d",& P);
	int tmarks = M+H+E+C+P;
	float per=tmarks/5;
	if(per>=33 && per<=100)
	{
		printf("passed\n");
		printf("total marks = %d",tmarks);
		
	}
else if(per<33)
{
printf("fail");
}
else 
{
printf("please enter your marks under 100");
}
return 0;
}
