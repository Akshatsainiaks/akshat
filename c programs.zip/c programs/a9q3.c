#include<stdio.h>
int main()
{
	int n;
	printf("enter your number = ");
	scanf("%d",&n);
	if(n==0){
	
	printf("number is even");
}

}
