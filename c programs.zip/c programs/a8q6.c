#include<stdio.h>
int main()
{
int Mn;	
printf("enter your month number = ");	
scanf("%d",&Mn);
if(Mn==1 || Mn==3 || Mn==5 || Mn==7|| Mn==8|| Mn==10 || Mn==12)
{
printf(" this month has 31 days");
}
else if(Mn==2)
{
printf("this month has 28 days");
}
else if(Mn==4 || Mn==6 || Mn==9 || Mn==11)
{
printf("this month has 30 days");
}
else
{
printf("write the number of month correct");
}
return 0;
}
