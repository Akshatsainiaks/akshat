#include<stdio.h>
int main()
{
	int a;
	if ("user enter 9");
	{printf("right");
	}
printf("enter number",& a);
scanf("%d",&a);

}
