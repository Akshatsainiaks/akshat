#include<stdio.h>
/* Observe the output of every statement */
int main()
{

    printf("%lu\n",sizeof(char));
    printf("%lu\n",sizeof(int));
    printf("%lu\n",sizeof (float));
    printf("%lu\n",sizeof(double));
    return 0;
}