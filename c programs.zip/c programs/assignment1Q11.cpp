#include<stdio.h>
int main()
{
printf("AKSHAT\nKUMAR\nSAINI");
return 0;
}
