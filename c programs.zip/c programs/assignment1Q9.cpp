#include<stdio.h>
int main()
{
	
	printf(" TECHNO NJR INDIA \n TECHNO NJR INDiA");
	
	
	return 0;
}
