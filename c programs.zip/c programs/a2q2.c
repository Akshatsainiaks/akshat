#include<stdio.h>
int main()
{
	int a=10;
	printf("my name is akshat\n");
	printf("%d",a);
	return 0;
}
