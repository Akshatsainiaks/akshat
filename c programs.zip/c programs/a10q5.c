#include<stdio.h>
int main()
{
    int i;
    float f;
    printf("Testing of various airthmetic operations\n");
    i = 2/5;
    f = 2/5;
    printf("value of integer i is %d\n",i);
    printf("value of float f is %f\n",f);
    return 0;
    
    
}