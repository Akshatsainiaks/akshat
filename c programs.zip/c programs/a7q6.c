#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("enter an integer = ");
	scanf("%d", & a);
	b= a%2;
	if(b==0)
{
	
printf("integer is even");

}
    else
{
     printf("integer is odd");
}

return 0;
}
