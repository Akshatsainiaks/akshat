#include<stdio.h>
int main()
{


    int a = 0;
    double d = 10.21;
    printf("%lu\n",sizeof(a+d));
    return 0;
}