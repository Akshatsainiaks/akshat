#include<stdio.h>
int main()
{
	int a=10;
	int b=20;
	("akshat");
	printf("value of a is %d \n",a);
	printf("value of b is %d",b);
	return 0;
}
