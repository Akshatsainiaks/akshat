#include<stdio.h>
void sum();
void sub();
void mul();
int main()
{
    return 0;
}
void sum()
int a,b,sum;
printf("enter a and b = ")
