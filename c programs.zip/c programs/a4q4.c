#include<stdio.h>
int main()
{
	int a=35;
	int b=5;
	printf("result is %d", a/b);
	return 0;
}
