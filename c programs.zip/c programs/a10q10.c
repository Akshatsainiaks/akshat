#include<stdio.h>
int main()
{
    float f;
    printf("Testing of various airthmetic operations-2\n");

f = 2/9;
printf("1. Value of float f is %f\n",f);

f = 2.0/9;
printf("2. Value of float f is %f\n",f);

f = 2/9.0;
printf("3. Value of float f is %f\n",f);

f = 2.0/9.0;
printf("4. Value of float f is %f\n",f);

f = 9/2;
printf("5. Value of float f is %f\n",f);

f = 9.0/2;
printf("6. Value of float f is %f\n",f);

f = 9/2.0;
printf("7. Value of float f is %f\n",f);

f = 9.0/2.0;
printf("8. Value of float f is %f\n",f);

return 0;
}