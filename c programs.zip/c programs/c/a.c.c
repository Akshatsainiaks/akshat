#include<stdio.h>

void sum();
void sub();
int main()
{
	sum();
	sub();
	
	void sum()
	{
		int a,b,sum;
	printf("enter two nuumbers = ");
	scanf("%d %d",&a,&b);
	sum=a+b;
	printf("sum is = %d",sum);
	}
void sub()
{
	int a,b,sub;
printf("enter two numbers = ");
scanf("%d %d",&a,&b);
sub=a-b;
printf("sub is = %d",sub);
}
return 0;
}
