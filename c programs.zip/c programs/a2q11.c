#include<stdio.h>
int main()
{
	int 0 a;
	return 0;
}
