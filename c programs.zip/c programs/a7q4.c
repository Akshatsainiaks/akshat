#include<stdio.h>
int main()
{
int V;
printf("enter a value = ");
scanf("%d",& V);
if(V>10)
{
printf("value %d is greater than 10 ",V);

}
else 
{
printf("value %d is less than 10",V);

}
return 0;
}
