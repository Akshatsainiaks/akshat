#include<stdio.h>
int main()
{
	int a;
	int b;
	int c;
	
	printf("write lenght of rectangle = ", & a);
scanf("%d", & a);	
}
