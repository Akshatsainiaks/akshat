#include<stdio.h>
int main()
{
	int cp;
	int sp;
	
	printf("enter cost price = ");
	scanf("%d",& cp);
	printf("enter selling price =  ");
	scanf("%d",& sp);
	
	if(sp>cp)
	{
		int profit;
		float p;
		profit=sp-cp;
		printf("profit %d \n",profit);
		p= (profit*100)/cp;
		printf("profit %f \n",p);
		}
else
{
	int loss;
	loss=cp-sp;
	float l;
	printf("loss %d\n",loss);
	l= (loss*100)/cp;
		printf("loss %f\n",l);

	}	
}
