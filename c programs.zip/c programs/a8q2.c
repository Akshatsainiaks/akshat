#include<stdio.h>
int main()
{
int sub1,sub2,sub3,sub4,sub5;
printf("enter marks of subject1 = ",sub1);
scanf("%d",&sub1);
printf("enter marks of subject2 = ",sub2);
scanf("%d",&sub2);
printf("enter marks of subject3 = ",sub3);
scanf("%d",&sub3);
printf("enter marks of subject4 = ",sub4);
scanf("%d",&sub4);
printf("enter marks of subject5 = ",sub5);
scanf("%d",&sub5);

int Tmarks=sub1+sub2+sub3+sub4+sub5;
float per=Tmarks/5;
if(per>=33 && per<=100)
{
printf("PASSED");
}
else if(per<33)
{
printf("FAILLED");
}
else
{
printf("ENTER YOUR MARKS UNDER 100");
}
return 0;

}
