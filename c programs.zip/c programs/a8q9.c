#include<stdio.h>
int main()
{
int N;
printf("enter number  = ");
scanf("%d",& N);
int UD=N%1;
printf("unit digit of number is %d", N);
return 0;	
}
